from django.apps import AppConfig


class FunctionConfig(AppConfig):
    name = 'dataAnalysis'
